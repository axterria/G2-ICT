<!DOCTYPE html>
<html>
  <head>
    <title>Group 2 ICT 10-MNEMOSYNE</title>
  </head>

  <body>
Juliana Anne G. Punzalan
Ashley Q. Bukid
Christel Angela Mago
Shena Gediela
Ashley Alimagno
Lance Jefferson Hausa
Lean Rick Convento
Diehlon Leander Nera
Janly Palma
Aihron Maligaya
</body>

</html>
